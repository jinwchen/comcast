package com.cim;

import java.util.ArrayList;
import java.util.List;

public class AdDatabase {
	
	static List<AdCampaign> listAd = new ArrayList<AdCampaign>();
	
	public static List<AdCampaign> getListAd() {
		return listAd;
	}
}
